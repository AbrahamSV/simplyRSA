from setuptools import setup

setup(

    name="simplyRSA",
    version="1.01",
    description="Simple package for RSA analyses",
    author="Abraham Sanchez",
    author_email="abrahamss.av@gmail.com",
    packages=["simplyRSA"]
)